console.log("page loaded...");

function play(element) { 
    element.play(); 
    console.log("play...");
} 

  function pause(element) { 
    element.pause(); 
    console.log("pause...");
} 

 