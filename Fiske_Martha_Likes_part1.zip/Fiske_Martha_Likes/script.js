console.log("page loaded...");
var likes=3;
var likeElement = document.querySelector("#likes")

function addLike() { 
        likes++;
        likeElement.innerText = likes +" like(s)";
} 

 